<?php
return [
    's3' => [
        'key' => 'AKIAJIRZMMG6N27JPYNA',
        'secret' => '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',
        'bucket' => 'plan-b-amazon'
    ]
];
?>